namespace Ej11
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        Random r=new Random();
        private void bTirar_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            int sum = 0;
            for(int i = 0; i < nDados.Value; i++)
            {
                int n = r.Next(1, (int)nCaras.Value);
                listBox1.Items.Add(n);
                sum += n;
            }
            tSuma.Text = sum.ToString();
        }
    }
}