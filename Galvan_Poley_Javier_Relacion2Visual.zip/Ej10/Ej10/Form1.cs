namespace Ej10
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            if (File.Exists("traductor.txt"))
            {            
                CargaDiccionario();
            }
            
        }
        public void CargaDiccionario()
        {
            StreamReader sr = new StreamReader("traductor.txt");
            while (!sr.EndOfStream)
            {
                listBox1.Items.Add(sr.ReadLine());
            }
            sr.Close();
        }
        private void bA�adir_Click(object sender, EventArgs e)
        {
            if(tEsp.Text !="" && tIng.Text != "")
            {
                listBox1.Items.Add(tEsp.Text + ", " + tIng.Text);
                tEsp.Text = "";
                tIng.Text = "";
            }
            else
            {
                MessageBox.Show("No puede estar vac�o","Error",MessageBoxButtons.OK,MessageBoxIcon.Error);
            }
            
            
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(listBox1.SelectedIndex == -1)
            {
                bDelete.Enabled = false;
            }
            else
            {
                bDelete.Enabled = true;
            }
        }

        private void bDelete_Click(object sender, EventArgs e)
        {
            listBox1.Items.RemoveAt(listBox1.SelectedIndex);
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            StreamWriter sr = new StreamWriter("traductor.txt");
            for(int i = 0; i < listBox1.Items.Count; i++)
            {
                sr.WriteLine(listBox1.Items[i].ToString());
            }
            sr.Close();
        }
    }
}