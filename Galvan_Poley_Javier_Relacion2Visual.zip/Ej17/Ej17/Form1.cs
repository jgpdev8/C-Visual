namespace Ej17
{
    public partial class Form1 : Form
    {
        bool modified = false;
        string nombrearchivo = "SinTitulo";
        public Form1(string [] args)
        {
            InitializeComponent();
            if (args.Length > 0)
            {
                if (File.Exists(args[0]))
                {
                    this.Text = Path.GetFileName(args[0]) + " : Bloc de notas";
                    textBox1.Text = File.ReadAllText(args[0]);
                    nombrearchivo = args[0];
                }

            }
            else
            {
                this.Text = nombrearchivo + " : Bloc de notas";
            }
            
        }

        private void nuevoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (modified)
            {
                DialogResult dr = MessageBox.Show("�Quieres guardar los cambios de " + nombrearchivo + "?", "Guardado", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question);
                if (dr == DialogResult.Yes)
                {
                    if (File.Exists(nombrearchivo))
                    {
                        File.WriteAllText(nombrearchivo, textBox1.Text);
                    }
                    else
                    {
                        GuardarComo();
                    }                           
                }
                else
                {
                    if (dr == DialogResult.No)
                    {
                        textBox1.Text = "";
                    }                    
                }
            }
            else
            {
                textBox1.Text = "";
            }

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            modified = true;
            CuentaLineas();
        }

        private bool GuardarComo()
        {
            DialogResult dr = saveFileDialog1.ShowDialog();
            if (dr == DialogResult.OK)
            {
                nombrearchivo = saveFileDialog1.FileName;
                File.WriteAllText(nombrearchivo, textBox1.Text);
                modified = false;
                return true;
            }
            else
            {
                return false;
            }
        }
        private bool Abrir()
        {
            DialogResult dr2 = openFileDialog1.ShowDialog();
            if (dr2 == DialogResult.OK)
            {
                nombrearchivo = openFileDialog1.FileName;
                textBox1.Text = File.ReadAllText(openFileDialog1.FileName);
                modified = false;
                this.Text = Path.GetFileName(nombrearchivo) + " : Bloc de notas";
                return true;
            }
            else
            {
                return false;
            }            
        }

        private void guardarComoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            GuardarComo();
        }

        private void saveFileDialog1_FileOk(object sender, System.ComponentModel.CancelEventArgs e)
        {

        }

        private void abrirToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Abrir();
            this.Text = Path.GetFileName(nombrearchivo) + " : Bloc de notas";
        }

        private void guardarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (File.Exists(nombrearchivo))
            {
                File.WriteAllText(nombrearchivo, textBox1.Text);
                modified = false;
            }
            else
            {
                GuardarComo();
            }
        }

        private void salirToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (modified)
            {
                DialogResult dr = MessageBox.Show("�Quieres guardar los cambios de "+nombrearchivo+"?", "Guardado", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question);
                if (dr == DialogResult.Yes)
                {
                    if (File.Exists(nombrearchivo))
                    {
                        File.WriteAllText(nombrearchivo, textBox1.Text);
                    }
                    else
                    {
                        GuardarComo();
                    }

                }
                else
                {
                    if (dr == DialogResult.Cancel)
                    {
                        e.Cancel = true;
                    }
                }
            }
        }

        private void deshacerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            textBox1.Undo();
        }

        private void copiarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            textBox1.Copy();
        }

        private void pegarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            textBox1.Paste();
        }

        private void eliminarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            textBox1.Cut();
        }

        

        private void horaYFechaToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            textBox1.Text += DateTime.Now.ToString();
        }

        private void Eliminar_Click(object sender, EventArgs e)
        {
            textBox1.SelectedText = "";
        }

        private void ajusteDeL�neaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (textBox1.WordWrap)
            {
                textBox1.WordWrap = false;
                ajusteDeL�neaToolStripMenuItem.Checked = false;
            }
            else
            {
                textBox1.WordWrap = true;
                ajusteDeL�neaToolStripMenuItem.Checked = true;
            }            
        }

        private void fuenteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DialogResult dr = fontDialog1.ShowDialog();

            if(dr == DialogResult.OK)
            {
                textBox1.Font = fontDialog1.Font;
            }
            
        }

        private void barraDeEstadoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (statusStrip1.Visible)
            {
                statusStrip1.Visible = false;
                barraDeEstadoToolStripMenuItem.Checked = false;
            }
            else
            {
                statusStrip1.Visible = true;
                barraDeEstadoToolStripMenuItem.Checked = true;
            }
        }

        private void CuentaLineas()
        {
            int linea=1, columna=1;
            for(int i = 0; i < textBox1.SelectionStart;i++)
            {
                if(textBox1.Text[i] == '\r' && textBox1.Text[i + 1] == '\n')
                {
                    linea++;
                    columna = 0;
                }
                else
                {
                    columna++;
                }
            }
            toolStripStatusLabel1.Text = "Linea: " + linea + ",columna: " + columna;
        }

        private void textBox1_MouseClick(object sender, MouseEventArgs e)
        {
            CuentaLineas();
        }

        private void textBox1_KeyDown(object sender, KeyEventArgs e)
        {
            CuentaLineas();
        }

        private void textBox1_KeyUp(object sender, KeyEventArgs e)
        {
            CuentaLineas();
        }
    }
}