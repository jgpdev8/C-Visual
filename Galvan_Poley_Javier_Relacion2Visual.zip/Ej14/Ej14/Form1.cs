namespace Ej14
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            StreamReader sr = new StreamReader("palabra1.txt");
            while (!sr.EndOfStream)
            {
                comboBox1.Items.Add(sr.ReadLine());
            }
            sr.Close();
            sr = new StreamReader("palabra2.txt");
            while (!sr.EndOfStream)
            {
                comboBox2.Items.Add(sr.ReadLine());
            }
            sr.Close ();
        }
        Random r = new Random();
        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            lTitle.Text = comboBox1.SelectedItem.ToString() +" "+ comboBox2.SelectedItem.ToString();
            lTitle.ForeColor = Color.FromArgb(r.Next(0, 255), r.Next(0, 255), r.Next(0, 255));
        }

        private void bRandom_Click(object sender, EventArgs e)
        {
            lTitle.Text=comboBox1.Items[r.Next(0,comboBox1.Items.Count)].ToString() + " "+comboBox2.Items[r.Next(0,comboBox2.Items.Count)].ToString();
            lTitle.ForeColor = Color.FromArgb(r.Next(0, 255), r.Next(0, 255), r.Next(0, 255));
        }
    }
}