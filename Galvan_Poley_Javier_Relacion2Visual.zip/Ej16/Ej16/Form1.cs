namespace Ej16
{
    public partial class Gatos : Form
    {
        int index;
        bool modify = false;
        public Gatos()
        {
            InitializeComponent();
            CargaCSV();
        }

        private void bNuevo_Click(object sender, EventArgs e)
        {
            TextBox[] datos = { tNombre, tPelo, tRaza, tPeso, tTama�o, tOjos };
            for (int i = 0; i < datos.Length; i++)
            {
                datos[i].Text = "";
            }
        }

        private void bSave_Click(object sender, EventArgs e)
        {
            TextBox[] datos = { tNombre, tPelo, tRaza, tPeso, tTama�o, tOjos };            
            if (modify == true)
            {
                listView1.Items.RemoveAt(index);
                modify = false;
            }
            for (int i = 0; i < 6; i++)
            {
                if (datos[i].Text == "")
                {
                    MessageBox.Show("Los datos no pueden estar vacios", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    string [] info = new string[datos.Length];
                    for(i=0;i<info.Length; i++)
                    {
                        info[i] = datos[i].Text;
                    }
                    ListViewItem lvi = new ListViewItem(info);
                    listView1.Items.Add(lvi);
                }
            }
        }

        private void bDelete_Click(object sender, EventArgs e)
        {
            for(int i = 0; i < listView1.SelectedIndices.Count; i++)
            {
                listView1.Items.RemoveAt(listView1.SelectedIndices[i]);
            }
        }

        private void bMod_Click(object sender, EventArgs e)
        {
            index = listView1.SelectedIndices[0];
            TextBox[] datos = { tNombre, tPelo, tRaza, tPeso, tTama�o, tOjos };
            for(int i = 0; i < datos.Length; i++)
            {
                datos[i].Text = listView1.SelectedItems[0].SubItems[i].Text;
            }

            
            modify = true;
        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listView1.SelectedIndices.Count > 0)
            {
                bMod.Enabled = true;
            }
            else
            {
                bMod.Enabled = false;
            }
        }

        private void Gatos_FormClosing(object sender, FormClosingEventArgs e)
        {
            StreamWriter sw = new StreamWriter("gatos.csv");
            string linea = "";
            for(int i = 0; i < listView1.Columns.Count; i++)
            {
                if(i == listView1.Columns.Count - 1)
                {
                    linea = linea + listView1.Columns[i].Text;
                }
                else
                {
                    linea = linea + listView1.Columns[i].Text + ";";
                }                    
            }
            sw.WriteLine(linea);
            for(int i = 0; i < listView1.Items.Count; i++)
            {
                linea = "";
                for(int j=0;j<listView1.Items[i].SubItems.Count; j++)
                {
                    if(j == listView1.Items[i].SubItems.Count - 1)
                    {
                        linea = linea + listView1.Items[i].SubItems[j].Text;
                    }
                    else
                    {
                        linea = linea + listView1.Items[i].SubItems[j].Text+";";
                    }                    
                }
                sw.WriteLine(linea);
            }
            sw.Close();
        }
        private void CargaCSV()
        {
            StreamReader sr = new StreamReader("gatos.csv");
            sr.ReadLine();
            while (!sr.EndOfStream)
            {
                string[] linea = sr.ReadLine().Split(';');
                ListViewItem lvi = new ListViewItem(linea);
                listView1.Items.Add(lvi);
            }
            sr.Close();
        }
    }
}