namespace Ej18
{
    public partial class Form1 : Form
    {
        int n = 1;
        int posx=0; 
        int posy = 0;
        Button[] botones=new Button[64];
        public Form1()
        {
            InitializeComponent();
            MakeButtons();
            this.FormBorderStyle= FormBorderStyle.FixedSingle;
        }

        private void MakeButtons()
        {
            for(int i = 0; i < 64; i++)
            {
                Button button = new Button();
                button.Text = n.ToString();               
                n++;
                botones[i] = button;
                button.Location = new Point(posy, posx);
                posy += 90;
                if (i % 4 == 1)
                {
                    posy += 90;
                }
                if (i % 4 == 3)
                {
                    posx += 30;
                    posy = 0;
                }
                button.Click += new EventHandler(Asiento_Click);
                button.BackColor = Color.Green;
                panel1.Controls.Add(button);
            }
        }
            
        private void Asiento_Click(object Sender, EventArgs e)
        {
            Button mybutton = (Button)Sender;
            if(mybutton.BackColor == Color.Orange)
            {
                mybutton.BackColor = Color.Green;
            }
            else
            {
                mybutton.BackColor = Color.Orange;
            }
            
        }
        private void bReservar_Click(object sender, EventArgs e)
        {
            if (tName.Text == "" || tName.Text == null)
            {
                MessageBox.Show("El nombre no puede estar vac�o", "Error en el textbox", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                string s = "";
                for (int i = 0; i < 64; i++)
                {
                    if (botones[i].BackColor == Color.Orange)
                    {
                        s += botones[i].Text + ", ";
                        botones[i].BackColor = Color.Red;
                        botones[i].Enabled = false;
                    }
                }
                if (s.Length > 2)
                {
                    s = s.Substring(0, s.Length - 2);
                    string[] lista = new string[2];
                    lista[0] = tName.Text;
                    lista[1] = s;
                    ListViewItem lvi = new ListViewItem(lista);
                    listView1.Items.Add(lvi);
                }
                else
                {
                    MessageBox.Show("Hay que seleccionar alg�n asiento", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

               
            }
            
            
        }

        private void tName_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                bReservar_Click(sender,e);
            }
        }
    }
}