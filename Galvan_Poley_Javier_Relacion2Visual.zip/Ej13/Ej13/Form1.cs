namespace Ej13
{
    public partial class Form1 : Form
    {
        int cont = 1;
        int aciertos = 0;
        List<string> answer = new List<string>();
        List<string> correct = new List<string>();
        public Form1()
        {
            InitializeComponent();
            correct.Add("Switch");
            correct.Add("Router");
            correct.Add("Repetidor");
            correct.Add("Rack");
            correct.Add("cable rj45");
            
        }
        
        private void bStart_Click(object sender, EventArgs e)
        {
            label1.Text = "1.-�Que componente es este?";
            label1.Location = new Point(100, 100);
            pictureBox1.Image = Image.FromFile("switch.jpg");
            
            rAns1.Text = "Switch";
            rAns2.Text = "Router";
            rAns3.Text = "Conmutador";
            rAns1.Visible = true;
            rAns2.Visible = true;
            rAns3.Visible = true;
            pictureBox1.Visible = true;
            bStart.Enabled = false;
            bStart.Visible = false;
        }

        private void bNext_Click(object sender, EventArgs e)
        {
            
                if (rAns1.Checked)
                {
                    answer.Add(rAns1.Text);
                }
                else
                {
                    if (rAns2.Checked)
                    {
                        answer.Add(rAns2.Text);
                    }
                    else
                    {
                        answer.Add(rAns3.Text);
                    }
                }
                cont++;
                label1.Text = cont.ToString() + ".-�Qu� componente es este?";
                switch (cont)
                {
                    case 2:
                        pictureBox1.Image = Image.FromFile("router.jpg");
                        rAns1.Text = "Switch";
                        rAns2.Text = "Router";
                        rAns3.Text = "Conmutador";
                        break;
                    case 3:
                        pictureBox1.Image = Image.FromFile("Repetidor.jpg");
                        rAns1.Text = "Repetidor";
                        rAns2.Text = "Router";
                        rAns3.Text = "Conmutador";
                        break;
                    case 4:
                        pictureBox1.Image = Image.FromFile("rack.jpg");
                        rAns1.Text = "Rack";
                        rAns2.Text = "Armario";
                        rAns3.Text = "Carcasa";
                        break;
                    case 5:
                        pictureBox1.Image = Image.FromFile("cablerj45.jpg");
                        rAns1.Text = "cable rj45";
                        rAns2.Text = "cable usb";
                        rAns3.Text = "cable DVI";
                        break;
                    case 6:
                        bNext.Visible = false;
                        label1.Visible = false;
                        rAns1.Visible = false;
                        rAns2.Visible = false;
                        rAns3.Visible = false;
                        pictureBox1.Visible = false;
                        for (int i = 0; i < 5; i++)
                        {
                            if (answer[i] == correct[i])
                            {
                                aciertos++;
                            }
                            if (answer[i] != correct[i])
                            {
                            tRespuestas.Text = tRespuestas.Text + (i + 1).ToString() + " " + answer[i] + " (incorrecto)" + "\r\n";
                            }
                            else
                            {
                            tRespuestas.Text = tRespuestas.Text + (i + 1).ToString() + " " + answer[i] + " (correcto)" + "\r\n";
                            }
                            tCorrectas.Text = tCorrectas.Text + (i + 1).ToString() +" "+ correct[i] + "\r\n";
                        }
                        lAciertos.Text = lAciertos.Text + " " + aciertos.ToString();
                        lAciertos.Visible = true;
                        label2.Visible = true;
                        label3.Visible = true;
                        tRespuestas.Visible = true;
                        tCorrectas.Visible = true;
                        break;
                }
                                    
            
            
        }

    }
}