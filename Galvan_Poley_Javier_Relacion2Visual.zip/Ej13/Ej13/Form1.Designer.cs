﻿namespace Ej13
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.bStart = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.bNext = new System.Windows.Forms.Button();
            this.rAns1 = new System.Windows.Forms.RadioButton();
            this.rAns2 = new System.Windows.Forms.RadioButton();
            this.rAns3 = new System.Windows.Forms.RadioButton();
            this.tRespuestas = new System.Windows.Forms.TextBox();
            this.tCorrectas = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lAciertos = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(210, 95);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(249, 37);
            this.label1.TabIndex = 0;
            this.label1.Text = "Test De 5 Preguntas";
            // 
            // bStart
            // 
            this.bStart.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.bStart.Location = new System.Drawing.Point(336, 233);
            this.bStart.Name = "bStart";
            this.bStart.Size = new System.Drawing.Size(115, 47);
            this.bStart.TabIndex = 1;
            this.bStart.Text = "Comenzar";
            this.bStart.UseVisualStyleBackColor = true;
            this.bStart.Click += new System.EventHandler(this.bStart_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(518, 60);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(225, 138);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 2;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Visible = false;
            // 
            // bNext
            // 
            this.bNext.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.bNext.Location = new System.Drawing.Point(623, 355);
            this.bNext.Name = "bNext";
            this.bNext.Size = new System.Drawing.Size(102, 39);
            this.bNext.TabIndex = 3;
            this.bNext.Text = "Siguiente";
            this.bNext.UseVisualStyleBackColor = true;
            this.bNext.Click += new System.EventHandler(this.bNext_Click);
            // 
            // rAns1
            // 
            this.rAns1.AutoSize = true;
            this.rAns1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.rAns1.Location = new System.Drawing.Point(210, 173);
            this.rAns1.Name = "rAns1";
            this.rAns1.Size = new System.Drawing.Size(119, 25);
            this.rAns1.TabIndex = 4;
            this.rAns1.TabStop = true;
            this.rAns1.Text = "radioButton1";
            this.rAns1.UseVisualStyleBackColor = true;
            this.rAns1.Visible = false;
            // 
            // rAns2
            // 
            this.rAns2.AutoSize = true;
            this.rAns2.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.rAns2.Location = new System.Drawing.Point(211, 216);
            this.rAns2.Name = "rAns2";
            this.rAns2.Size = new System.Drawing.Size(119, 25);
            this.rAns2.TabIndex = 5;
            this.rAns2.TabStop = true;
            this.rAns2.Text = "radioButton1";
            this.rAns2.UseVisualStyleBackColor = true;
            this.rAns2.Visible = false;
            // 
            // rAns3
            // 
            this.rAns3.AutoSize = true;
            this.rAns3.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.rAns3.Location = new System.Drawing.Point(210, 255);
            this.rAns3.Name = "rAns3";
            this.rAns3.Size = new System.Drawing.Size(119, 25);
            this.rAns3.TabIndex = 6;
            this.rAns3.TabStop = true;
            this.rAns3.Text = "radioButton1";
            this.rAns3.UseVisualStyleBackColor = true;
            this.rAns3.Visible = false;
            // 
            // tRespuestas
            // 
            this.tRespuestas.BackColor = System.Drawing.SystemColors.Control;
            this.tRespuestas.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.tRespuestas.ForeColor = System.Drawing.SystemColors.MenuText;
            this.tRespuestas.Location = new System.Drawing.Point(77, 216);
            this.tRespuestas.Multiline = true;
            this.tRespuestas.Name = "tRespuestas";
            this.tRespuestas.ReadOnly = true;
            this.tRespuestas.Size = new System.Drawing.Size(297, 169);
            this.tRespuestas.TabIndex = 7;
            this.tRespuestas.Visible = false;
            // 
            // tCorrectas
            // 
            this.tCorrectas.AcceptsReturn = true;
            this.tCorrectas.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.tCorrectas.Location = new System.Drawing.Point(428, 216);
            this.tCorrectas.Multiline = true;
            this.tCorrectas.Name = "tCorrectas";
            this.tCorrectas.ReadOnly = true;
            this.tCorrectas.Size = new System.Drawing.Size(297, 169);
            this.tCorrectas.TabIndex = 8;
            this.tCorrectas.Visible = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(77, 183);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(89, 15);
            this.label2.TabIndex = 9;
            this.label2.Text = "Tus Respuestas:";
            this.label2.Visible = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(428, 183);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(119, 15);
            this.label3.TabIndex = 10;
            this.label3.Text = "Respuestas correctas:";
            this.label3.Visible = false;
            // 
            // lAciertos
            // 
            this.lAciertos.AutoSize = true;
            this.lAciertos.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lAciertos.Location = new System.Drawing.Point(350, 132);
            this.lAciertos.Name = "lAciertos";
            this.lAciertos.Size = new System.Drawing.Size(118, 37);
            this.lAciertos.TabIndex = 11;
            this.lAciertos.Text = "Aciertos:";
            this.lAciertos.Visible = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lAciertos);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.tCorrectas);
            this.Controls.Add(this.tRespuestas);
            this.Controls.Add(this.rAns3);
            this.Controls.Add(this.rAns2);
            this.Controls.Add(this.rAns1);
            this.Controls.Add(this.bNext);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.bStart);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Supertest";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label label1;
        private Button bStart;
        private PictureBox pictureBox1;
        private Button bNext;
        private RadioButton rAns1;
        private RadioButton rAns2;
        private RadioButton rAns3;
        private TextBox tRespuestas;
        private TextBox tCorrectas;
        private Label label2;
        private Label label3;
        private Label lAciertos;
    }
}