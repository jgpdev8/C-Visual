namespace Ej12
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void bConvertir_Click(object sender, EventArgs e)
        {
            if (rKmsMillas.Checked)
            {
                tDos.Text = (int.Parse(tUno.Text)/1.609344).ToString();
                lUnidades1.Text = "Kms";
                lUnidades2.Text = "Millas";
            }
            else
            {
                if (rMillasKms.Checked)
                {
                    tDos.Text = (int.Parse(tUno.Text)*1.609344).ToString();
                    lUnidades1.Text = "Millas";
                    lUnidades2.Text = "Kms";
                }
            }
        }
    }
}