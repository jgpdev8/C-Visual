﻿namespace Ej12
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tUno = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.tDos = new System.Windows.Forms.TextBox();
            this.rKmsMillas = new System.Windows.Forms.RadioButton();
            this.label2 = new System.Windows.Forms.Label();
            this.rMillasKms = new System.Windows.Forms.RadioButton();
            this.bConvertir = new System.Windows.Forms.Button();
            this.lUnidades1 = new System.Windows.Forms.Label();
            this.lUnidades2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // tUno
            // 
            this.tUno.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.tUno.Location = new System.Drawing.Point(262, 163);
            this.tUno.Name = "tUno";
            this.tUno.Size = new System.Drawing.Size(170, 43);
            this.tUno.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 30F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.World);
            this.label1.Location = new System.Drawing.Point(271, 59);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(221, 41);
            this.label1.TabIndex = 1;
            this.label1.Text = "MultiConversor";
            // 
            // tDos
            // 
            this.tDos.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.tDos.Location = new System.Drawing.Point(546, 163);
            this.tDos.Name = "tDos";
            this.tDos.ReadOnly = true;
            this.tDos.Size = new System.Drawing.Size(170, 43);
            this.tDos.TabIndex = 2;
            // 
            // rKmsMillas
            // 
            this.rKmsMillas.AutoSize = true;
            this.rKmsMillas.Location = new System.Drawing.Point(12, 149);
            this.rKmsMillas.Name = "rKmsMillas";
            this.rKmsMillas.Size = new System.Drawing.Size(91, 19);
            this.rKmsMillas.TabIndex = 3;
            this.rKmsMillas.TabStop = true;
            this.rKmsMillas.Text = "Kms a Millas";
            this.rKmsMillas.UseVisualStyleBackColor = true;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label2.Location = new System.Drawing.Point(12, 116);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(185, 21);
            this.label2.TabIndex = 4;
            this.label2.Text = "Selecciona la Conversión:";
            // 
            // rMillasKms
            // 
            this.rMillasKms.AutoSize = true;
            this.rMillasKms.Location = new System.Drawing.Point(12, 187);
            this.rMillasKms.Name = "rMillasKms";
            this.rMillasKms.Size = new System.Drawing.Size(91, 19);
            this.rMillasKms.TabIndex = 5;
            this.rMillasKms.TabStop = true;
            this.rMillasKms.Text = "Millas a Kms";
            this.rMillasKms.UseVisualStyleBackColor = true;
            // 
            // bConvertir
            // 
            this.bConvertir.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.bConvertir.Location = new System.Drawing.Point(46, 348);
            this.bConvertir.Name = "bConvertir";
            this.bConvertir.Size = new System.Drawing.Size(129, 45);
            this.bConvertir.TabIndex = 6;
            this.bConvertir.Text = "Convertir";
            this.bConvertir.UseVisualStyleBackColor = true;
            this.bConvertir.Click += new System.EventHandler(this.bConvertir_Click);
            // 
            // lUnidades1
            // 
            this.lUnidades1.AutoSize = true;
            this.lUnidades1.Location = new System.Drawing.Point(452, 179);
            this.lUnidades1.Name = "lUnidades1";
            this.lUnidades1.Size = new System.Drawing.Size(0, 15);
            this.lUnidades1.TabIndex = 7;
            // 
            // lUnidades2
            // 
            this.lUnidades2.AutoSize = true;
            this.lUnidades2.Location = new System.Drawing.Point(740, 178);
            this.lUnidades2.Name = "lUnidades2";
            this.lUnidades2.Size = new System.Drawing.Size(0, 15);
            this.lUnidades2.TabIndex = 8;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lUnidades2);
            this.Controls.Add(this.lUnidades1);
            this.Controls.Add(this.bConvertir);
            this.Controls.Add(this.rMillasKms);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.rKmsMillas);
            this.Controls.Add(this.tDos);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.tUno);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private TextBox tUno;
        private Label label1;
        private TextBox tDos;
        private RadioButton rKmsMillas;
        private Label label2;
        private RadioButton rMillasKms;
        private Button bConvertir;
        private Label lUnidades1;
        private Label lUnidades2;
    }
}