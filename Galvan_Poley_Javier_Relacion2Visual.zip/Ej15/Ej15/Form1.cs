namespace Ej15
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void bLoad_Click(object sender, EventArgs e)
        {
            if (File.Exists(tFichero.Text) == false)
            {
                MessageBox.Show("El fichero no existe", "Error", MessageBoxButtons.OK,MessageBoxIcon.Error);
            }
            else
            {
                StreamReader sr = new StreamReader(tFichero.Text);
                string[] palabras = sr.ReadLine().Split(';');
                for(int i = 0; i < palabras.Length; i++)
                {
                    listView1.Columns.Add(palabras[i]);
                }
                while (!sr.EndOfStream)
                {
                    palabras= sr.ReadLine().Split(';');
                    
                    ListViewItem lvi = new ListViewItem(palabras);
                    listView1.Items.Add(lvi);
                }
            }
            

        }
    }
}